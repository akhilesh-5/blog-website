<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a href="{{ $link }}">{{ $link }}</a>