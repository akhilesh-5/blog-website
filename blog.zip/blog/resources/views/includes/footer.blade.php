<div class="footer-main">
      <div class="main-footer text-right">
        <span class="cptext">© Copyright 2024 ABC Technology (S) Pte. Ltd.</span>
    </div>
</div>

 
  <script src="{{ url('assets/js/popper.min.js') }}" ></script>
  <script src="{{ url('assets/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ url('assets/js/jquery.nicescroll.js') }}"></script>
  <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
  <script src="{{ url('assets/js/myadmin.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
<script src="{{ url('assets/js/jquery.min.js') }}"></script>


@yield('scripts')

 

  