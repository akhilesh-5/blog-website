<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
  <title>Blogs</title>
  <meta name="description" content="">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="shortcut icon" href="assets/">
  <link href="{{ url('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
  <link rel="{{ url('shortcut icon" type="image/png') }}" href="assets/images/favicon.png" />
  <link href="{{ url('assets/css/animate.css') }}" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="{{ url('assets/plugins/linearicons/inearicons-style.css') }}">
  <link href="{{ url('assets/css/admin-style.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('assets/css/dropdown.css') }}" rel="stylesheet" type="text/css" />
  