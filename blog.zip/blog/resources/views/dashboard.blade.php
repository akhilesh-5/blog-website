@extends('layouts')

@section('content')

<body class="adminbody">
  <div id="main">
    <!-- top bar navigation -->
    <div class="headerbar">
      <div class="stky">
        <nav class="navbar-custom">
          <div class="list-inline menu-left mb-0">
            <a class="xbutton  button-menu-mobile open-left">
              <small class="mnln1"></small>
            </a>
            <li>
            </li>
          </div>
        <div class="prf-slct">
            <small class="clndr"><ion-icon name="calendar-outline"></ion-icon></small>
            <ul class="list-inline float-right mb-0">
              <li class="list-inline-item dropdown notif"> <a class="nav-link dropdown-toggle nav-user"
                data-bs-toggle="dropdown"  href="#" role="button" aria-haspopup="false" aria-expanded="false">
                  <div class="use-admt-algn">
                    <span class="tlogdwn">
                      <ion-icon name="person-outline" class="avatar-rounded"></ion-icon>
                    </span>
                    <ul>
                      <li>
                        <b>Admin</b>
                      </li>
                    </ul>
                    <ion-icon class="down-outline" name="chevron-down-outline"></ion-icon>
                  </div>
                </a>
                <form action="{{ route('logout') }}" method="POST" id="logout-form">
                @csrf
                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                  <div class="drp-logout">
                  <a href="{{ route('logout') }}" class="notify-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                  <ion-icon name="log-out-outline"></ion-icon>
                      <span>Logout</span>
                    </a>
                  </div>
                </div>
                </form>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
    <!-- End Navigation -->
    <!-- Left Sidebar -->
    <!-- End Sidebar -->
   


  <!-- END main -->
  <div id="jsScroll" class="scrolltop hidescroll" onclick="scrollToTop();"> <ion-icon name="chevron-up-outline"></ion-icon></div>


  <!-- Tootltip -->
  <script>    
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>

  <!-- Scroll Indicator -->
  <script>
    window.addEventListener('scroll', e => {
        var el = document.getElementById('jsScroll');
        if (window.scrollY > 200) {
            el.classList.add('scrvisible');
        } else {
            el.classList.remove('scrvisible');
        }
    });
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
    </script>

    <script>
    let idleTimer = null;
    let idleState = false;
    function showFoo(time) {
        clearTimeout(idleTimer);
        if (idleState == true) {
            $(".hidescroll").removeClass("inactive");
        }
        idleState = false;
        idleTimer = setTimeout(function () {
            $(".hidescroll").addClass("inactive");
            idleState = true;
        }, time);
    }
    showFoo(2000);
    $(window).scroll(function () {
        showFoo(2000);
    });
    </script>

    <script>
      $(document).ready(function () {
        var stickyNavTop = $('.stky').offset().top;
        var stickyNav = function () {
          var scrollTop = $(window).scrollTop();
          if (scrollTop > stickyNavTop) {
            $('.stky').addClass('sticky');
          } else {
            $('.stky').removeClass('sticky');
          }
        };
        stickyNav();
        $(window).scroll(function () {
          stickyNav();
        });
      });
    </script>
@endsection