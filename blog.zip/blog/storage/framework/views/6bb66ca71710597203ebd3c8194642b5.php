<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a href="<?php echo e($link); ?>"><?php echo e($link); ?></a><?php /**PATH D:\xampp\htdocs\login\resources\views/email/forgetPassword.blade.php ENDPATH**/ ?>