

<?php $__env->startSection('content'); ?>

<div class="content-page">
    <div class="content">
        <div class="container-fluid">
            <div class="row mb-3">
                <div class="col-12">
                    <div class="brdcrmb-title">
                        <div class="breadcrumb-holder">
                            <h1 class="main-title float-left">View Blogs</h1>
                            <div class="toplnk text-center"> 
                                <a class="btn xbtn-srch collapsed" data-bs-toggle="collapse" href="#xsearchbox" aria-expanded="<?php echo e(request('role') ? 'true' : 'false'); ?>" aria-controls="xsearchbox">
                                    <ion-icon name="search-outline"></ion-icon>
                                </a>
                                <a href="<?php echo e(route('blogs.create')); ?>" class="btn xbtn-add">
                                    <ion-icon name="add-outline"></ion-icon> Add Blog
                                </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="collapse <?php echo e(request('title')  ? 'show' : ''); ?>" id="xsearchbox">
        <div class="card card-body xsearchbdy">
        <a class="cbtn-srch" data-bs-toggle="collapse" href="#xsearchbox" aria-expanded="true" aria-controls="xsearchbox" style="float: right;">
            <ion-icon name="close-outline" role="img" class="md hydrated" aria-label="close outline"></ion-icon>
        </a>
        <form autocomplete="off" action="<?php echo e(route('blogs.index')); ?>" method="GET" class="d-flex align-items-center gap-2">
            <div class="form-group mb-0 flex-grow-1">
                <label for="title" class="d-none">Title</label>
                <input type="text" id="title" name="title" class="form-control form-control-sm" 
                       placeholder="Title" value="<?php echo e(request('title')); ?>" style="max-width: 300px; width: 100%;">
            </div>
           
            <div class="form-group mb-0">
                <button type="submit" class="btn btn-primary btn-sm">
                    <ion-icon name="search-outline" role="img" class="md hydrated" aria-label="search outline"></ion-icon> Search
                </button>
                <a class="btn btn-secondary btn-sm" href="<?php echo e(route('blogs.index')); ?>">
                    <ion-icon name="close-outline" role="img" class="md hydrated" aria-label="close outline"></ion-icon> Cancel
                </a>
            </div>
        </form>
    </div>
</div>





            <div class="row">
                <div class="col-xl-12">
                    <div class="inr-frm-str">
                        <div class="inr-frm-sub">
                            <div class="in-page-tbl">
                                <div class="body-content mb-3">
                                    <div class="table-responsive tbl-bdy">
                                        <table class="table table-hover table-sm">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Title</th>
                                                    <th>Short Content</th>
                                                    <th>Actions</th>
                                                </tr>
                                                <?php
                                                 $serial = ($blogs->currentPage() - 1) * $blogs->perPage() + 1; // Calculate starting serial number
                                                ?>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($serial++); ?></td>
                                                    <td><?php echo e($blog->title); ?></td>
                                                    <td><?php echo e($blog->short_content); ?></td>
                                                    <td>

                                                        <form action="<?php echo e(route('blogs.destroy',$blog->id)); ?>" method="Post">
                                                        <button type="button" class="btn btn-primary btn-sm" onclick="window.location.href='<?php echo e(route('blogs.edit', $blog->id)); ?>'">Edit</button>

                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?');">
                                                                    Delete
                                                                </button>
                                                        </form>

                                                        </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                             <ul class="pagination">
                                                 <?php echo e($blogs->links('pagination::bootstrap-4')); ?>

                                             </ul>
                                         </div>
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card-->
                </div>
                <!-- end card-->
            </div>
        </div>
        <!-- END container-fluid -->
    </div>
    <!-- END content-page -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\login\resources\views/blogs/index.blade.php ENDPATH**/ ?>