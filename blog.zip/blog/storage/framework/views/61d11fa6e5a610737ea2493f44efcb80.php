<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
  <title>Blogs</title>
  <meta name="description" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="shortcut icon" href="assets/">
  <link href="<?php echo e(url('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link rel="<?php echo e(url('shortcut icon" type="image/png')); ?>" href="assets/images/favicon.png" />
  <link href="<?php echo e(url('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="<?php echo e(url('assets/plugins/linearicons/inearicons-style.css')); ?>">
  <link href="<?php echo e(url('assets/css/admin-style.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(url('assets/css/dropdown.css')); ?>" rel="stylesheet" type="text/css" />
  <?php /**PATH D:\xampp\htdocs\login\resources\views/includes/head.blade.php ENDPATH**/ ?>