<html lang="en" class="no-js">
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<?php error_reporting(0);?>
<body class="adminbody" >
    <!-- <div id="overlay">
        <div id="progstat"></div>
        <div id="progress"></div>
      </div>     -->
    <div id="main">
        <!-- header content -->
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- sidebar content -->
        <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <!-- main content -->
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('content'); ?>
        </div> 
        <!-- footer content -->
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
<!-- JS script include -->

</body>
</html><?php /**PATH D:\xampp\htdocs\login\resources\views/layouts.blade.php ENDPATH**/ ?>